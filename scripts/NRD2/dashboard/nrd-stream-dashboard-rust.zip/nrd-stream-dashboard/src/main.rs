use anyhow::{bail, Context, Result};
use chrono::Local;
use clap::{Parser, ValueEnum};
use crossterm::{cursor, execute, terminal::{self, ClearType}};
use futures_util::{SinkExt, StreamExt};
use serde_json::{json, Value};
use std::{collections::{BTreeMap, VecDeque}, fs::File, io::{self, BufWriter, IsTerminal, Write}, path::PathBuf, sync::{Arc, Mutex}, time::{Duration, Instant}};
use tokio::sync::{mpsc, watch};
use tokio_tungstenite::{connect_async, tungstenite::Message};

const CAPACITY: usize = 10_000;
type Row = (String, String, String);
type Shared = Arc<Mutex<Stats>>;

#[derive(Clone, Copy, ValueEnum)]
#[value(rename_all = "UPPER")]
enum Format { Csv, Json }

#[derive(Parser)]
#[command(about = "Stream newly registered domains with a live terminal dashboard")]
struct Args {
    output_file: PathBuf,
    #[arg(long, alias = "outputFormat", value_enum, default_value = "CSV")]
    output_format: Format,
    #[arg(long, env = "NRD_API_KEY", hide_env_values = true)]
    api_key: String,
    #[arg(long, default_value = "wss://nrd-stream.whoisxmlapi.com/ultimate", hide = true)]
    ws_url: String,
    #[arg(long, default_value_t = 2.0)]
    ws_timeout: f64,
    #[arg(long, default_value_t = 15.0)]
    connect_timeout: f64,
    #[arg(long, default_value_t = 30.0)]
    keepalive: f64,
    #[arg(long, default_value_t = 5)]
    max_retries: usize,
    #[arg(long, default_value_t = 5.0)]
    retry_delay: f64,
}

struct Stats {
    started: Instant,
    transactions: u64, records: u64, written: u64,
    counts: BTreeMap<String, u64>,
    reconnects: u64, errors: u64, decode_errors: u64, writer_errors: u64,
    dropped: u64, pings: u64,
    last_message: Option<Instant>, last_transaction: Option<Instant>, last_ping: Option<Instant>,
    last_error: String, state: String,
    recent: VecDeque<Row>, events: VecDeque<String>,
}
impl Stats {
    fn new() -> Self {
        Self { started: Instant::now(), transactions: 0, records: 0, written: 0,
            counts: BTreeMap::new(), reconnects: 0, errors: 0, decode_errors: 0,
            writer_errors: 0, dropped: 0, pings: 0, last_message: None,
            last_transaction: None, last_ping: None, last_error: "None".into(),
            state: "Starting".into(), recent: VecDeque::new(), events: VecDeque::new() }
    }
    fn event(&mut self, level: &str, message: &str) {
        if self.events.len() == 8 { self.events.pop_front(); }
        self.events.push_back(format!("{} {level}: {message}", Local::now().format("%H:%M:%S")));
    }
    fn error(&mut self, message: &str, decode: bool, writer: bool) {
        self.errors += 1; self.decode_errors += u64::from(decode);
        self.writer_errors += u64::from(writer); self.last_error = message.into();
        self.event("ERROR", message);
    }
}

// Never render untrusted control characters from records or errors.
fn clean(s: &str) -> String { s.chars().map(|c| if c.is_control() { ' ' } else { c }).collect() }
fn duration(d: Duration) -> String {
    let s = d.as_secs(); format!("{:02}:{:02}:{:02}", s / 3600, s / 60 % 60, s % 60)
}
fn age(t: Option<Instant>) -> String {
    t.map(|t| format!("{} ago", duration(t.elapsed()))).unwrap_or_else(|| "never".into())
}
fn field(v: &Value, key: &str, fallback: &str) -> String {
    match v.get(key) { None => fallback.into(), Some(Value::String(s)) => s.clone(), Some(v) => v.to_string() }
}

async fn process(raw: &str, stats: &Shared, tx: &mpsc::Sender<Row>) -> Result<()> {
    let record: Value = match serde_json::from_str(raw) {
        Ok(v) => v,
        Err(e) => { stats.lock().unwrap().error(&format!("Invalid JSON: {e}"), true, false); return Ok(()); }
    };
    if !record.is_object() {
        stats.lock().unwrap().error("JSON record is not an object", true, false); return Ok(());
    }
    let reason = field(&record, "reason", "unknown");
    let domain = field(&record, "domainName", "N/A");
    {
        let mut s = stats.lock().unwrap();
        s.records += 1; s.last_message = Some(Instant::now());
        let bucket = match reason.as_str() { "added" | "discovered" | "updated" | "dropped" => reason.as_str(), _ => "unknown" };
        *s.counts.entry(bucket.into()).or_default() += 1;
        if s.recent.len() == 6 { s.recent.pop_front(); }
        s.recent.push_back((Local::now().format("%H:%M:%S").to_string(), reason.clone(), domain.clone()));
    }
    if reason == "added" {
        let row = (Local::now().format("%Y-%m-%d %H:%M:%S%.3f").to_string(), reason, domain);
        match tokio::time::timeout(Duration::from_millis(250), tx.send(row)).await {
            Ok(Ok(())) => {},
            Ok(Err(_)) => bail!("Output writer stopped"),
            Err(_) => {
                let mut s = stats.lock().unwrap(); s.dropped += 1;
                s.error("Writer queue full; output row dropped", false, true);
            }
        }
    }
    Ok(())
}

// A dedicated blocking task owns all disk I/O. Dropping every sender drains the queue.
fn writer(file: File, format: Format, mut rx: mpsc::Receiver<Row>, stats: Shared) -> Result<()> {
    enum Output { Csv(csv::Writer<BufWriter<File>>), Json(BufWriter<File>) }
    let mut out = match format {
        Format::Csv => {
            let mut w = csv::Writer::from_writer(BufWriter::new(file));
            w.write_record(["Timestamp", "Reason", "DomainName"])?; w.flush()?;
            Output::Csv(w)
        },
        Format::Json => Output::Json(BufWriter::new(file)),
    };
    while let Some(first) = rx.blocking_recv() {
        let mut rows = vec![first];
        while rows.len() < 500 {
            match rx.try_recv() { Ok(row) => rows.push(row), Err(_) => break }
        }
        for (ts, reason, domain) in &rows {
            match &mut out {
                Output::Csv(w) => w.write_record([ts, reason, domain])?,
                Output::Json(w) => {
                    serde_json::to_writer(&mut *w, &json!({"timestamp": ts, "reason": reason, "domain": domain}))?;
                    w.write_all(b"\n")?;
                }
            }
        }
        match &mut out { Output::Csv(w) => w.flush()?, Output::Json(w) => w.flush()? }
        stats.lock().unwrap().written += rows.len() as u64;
    }
    stats.lock().unwrap().event("INFO", "Writer stopped; queued output flushed.");
    Ok(())
}

async fn connection(args: &Args, stats: &Shared, tx: &mpsc::Sender<Row>, stop: &mut watch::Receiver<bool>) -> Result<()> {
    let (mut ws, _) = tokio::time::timeout(Duration::from_secs_f64(args.connect_timeout), connect_async(&args.ws_url))
        .await.context("Connection timed out")??;
    tokio::time::timeout(Duration::from_secs_f64(args.connect_timeout), ws.send(Message::Text(args.api_key.clone().into())))
        .await.context("API key send timed out")??;
    {
        let mut s = stats.lock().unwrap(); s.state = "Streaming".into();
        s.event("INFO", "API key sent; WebSocket connected.");
    }
    let mut last_traffic = Instant::now();
    loop {
        tokio::select! {
            biased;
            _ = stop.changed() => { return Ok(()); }
            result = tokio::time::timeout(Duration::from_secs_f64(args.ws_timeout), ws.next()) => {
                match result {
                    Err(_) => {
                        if last_traffic.elapsed().as_secs_f64() >= args.keepalive {
                            tokio::time::timeout(Duration::from_secs_f64(args.ws_timeout), ws.send(Message::Ping(b"nrd-dashboard".to_vec().into())))
                                .await.context("Ping send timed out")??;
                            let mut s = stats.lock().unwrap(); s.pings += 1; s.last_ping = Some(Instant::now());
                            s.event("INFO", "Idle keep-alive ping sent."); last_traffic = Instant::now();
                        }
                    }
                    Ok(None) => bail!("Server closed the WebSocket"),
                    Ok(Some(Err(e))) => return Err(e.into()),
                    Ok(Some(Ok(msg))) => {
                        let payload = match msg {
                            Message::Text(t) => t.to_string(),
                            Message::Binary(b) => String::from_utf8_lossy(&b).into_owned(),
                            Message::Pong(_) => { stats.lock().unwrap().event("INFO", "Keep-alive pong received."); continue; }
                            Message::Ping(_) => {
                                // Tungstenite queues the matching pong automatically; flush it promptly.
                                tokio::time::timeout(Duration::from_secs_f64(args.ws_timeout), ws.flush()).await.context("Pong flush timed out")??;
                                continue;
                            }
                            Message::Close(_) => bail!("Server sent a close frame"),
                            _ => continue,
                        };
                        last_traffic = Instant::now();
                        { let mut s = stats.lock().unwrap(); s.transactions += 1; s.last_transaction = Some(Instant::now()); }
                        for line in payload.lines().map(str::trim).filter(|s| !s.is_empty()) {
                            if *stop.borrow() { return Ok(()); }
                            process(line, stats, tx).await?;
                        }
                    }
                }
            }
        }
    }
}

async fn stream(args: Arc<Args>, stats: Shared, tx: mpsc::Sender<Row>, mut stop: watch::Receiver<bool>) -> Result<()> {
    let mut retries = 0;
    while !*stop.borrow() {
        stats.lock().unwrap().state = "Connecting".into();
        let mut connection_stop = stop.clone();
        let result = tokio::select! {
            biased;
            _ = stop.changed() => break,
            result = connection(&args, &stats, &tx, &mut connection_stop) => result,
        };
        if *stop.borrow() { break; }
        // Mirror the Python client's reset after each successful connection.
        if stats.lock().unwrap().state == "Streaming" { retries = 0; }
        if let Err(e) = result {
            // Avoid accidentally displaying the API key in a server/library error.
            let message = format!("Connection problem: {e}").replace(&args.api_key, "[REDACTED]");
            stats.lock().unwrap().error(&message, false, false);
        }
        if tx.is_closed() { bail!("Output writer stopped"); }
        retries += 1;
        if retries > args.max_retries {
            stats.lock().unwrap().state = "Stopped: retry limit reached".into();
            bail!("Retry limit reached");
        }
        {
            let mut s = stats.lock().unwrap(); s.reconnects += 1;
            s.state = format!("Reconnecting ({retries}/{})", args.max_retries);
            s.event("WARNING", &format!("Reconnecting in {} seconds", args.retry_delay));
        }
        tokio::select! {
            _ = stop.changed() => break,
            _ = tokio::time::sleep(Duration::from_secs_f64(args.retry_delay)) => {}
        }
    }
    Ok(())
}

struct Screen(bool);
impl Screen {
    fn enter() -> Result<Self> {
        let active = io::stdout().is_terminal();
        if active { execute!(io::stdout(), terminal::EnterAlternateScreen, cursor::Hide)?; }
        Ok(Self(active))
    }
}
impl Drop for Screen {
    fn drop(&mut self) { if self.0 { let _ = execute!(io::stdout(), cursor::Show, terminal::LeaveAlternateScreen); } }
}
fn render(stats: &Shared, tx: &mpsc::Sender<Row>, args: &Args) -> Result<()> {
    let s = stats.lock().unwrap();
    let mut lines = vec![
        format!("NRD STREAM MONITOR   |   {}   |   Runtime {}", s.state, duration(s.started.elapsed())),
        format!("Output: {}", args.output_file.display()),
        String::new(),
        format!("Transactions: {}   Records: {}   Written: {}   Queue: {}/{}", s.transactions, s.records, s.written, CAPACITY - tx.capacity(), CAPACITY),
        format!("Last transaction: {}   Last record: {}", age(s.last_transaction), age(s.last_message)),
        format!("Keep-alives: {}   Last ping: {}", s.pings, age(s.last_ping)),
        String::new(),
        ["added", "discovered", "updated", "dropped", "unknown"].iter().map(|k| format!("{}: {}", k, s.counts.get(*k).unwrap_or(&0))).collect::<Vec<_>>().join("   "),
        String::new(),
        format!("Transmission errors: {}   Decode: {}   Writer: {}   Dropped rows: {}   Reconnects: {}", s.errors, s.decode_errors, s.writer_errors, s.dropped, s.reconnects),
        format!("Last error: {}", s.last_error),
        String::new(), "LATEST STREAM RECORDS".into(),
    ];
    for (time, reason, domain) in s.recent.iter().rev() { lines.push(format!("{time}  {reason:<12} {domain}")); }
    if s.recent.is_empty() { lines.push("Waiting for stream records...".into()); }
    lines.push(String::new()); lines.push("RECENT EVENTS".into());
    lines.extend(s.events.iter().cloned());
    let (width, height) = terminal::size().unwrap_or((120, 40));
    let mut stdout = io::stdout().lock();
    execute!(stdout, cursor::MoveTo(0, 0), terminal::Clear(ClearType::All))?;
    for line in lines.iter().take(height.saturating_sub(1) as usize) {
        writeln!(stdout, "{}\r", clean(line).chars().take(width.saturating_sub(1) as usize).collect::<String>())?;
    }
    stdout.flush()?; Ok(())
}

// Re-exec with a clean argv on Unix, as the Python original does.
fn hide_key() -> Result<()> {
    let mut args = std::env::args_os(); args.next();
    let mut remaining = Vec::new(); let mut key = None;
    while let Some(arg) = args.next() {
        if arg == "--api-key" { key = Some(args.next().context("--api-key requires a value")?); }
        else if let Some(value) = arg.to_str().and_then(|s| s.strip_prefix("--api-key=")) { key = Some(value.into()); }
        else { remaining.push(arg); }
    }
    if let Some(key) = key {
        let mut command = std::process::Command::new(std::env::current_exe()?);
        command.args(remaining).env("NRD_API_KEY", key);
        #[cfg(unix)] { use std::os::unix::process::CommandExt; return Err(command.exec().into()); }
        #[cfg(not(unix))] { std::process::exit(command.status()?.code().unwrap_or(1)); }
    }
    Ok(())
}
async fn shutdown_signal() -> Result<()> {
    #[cfg(unix)] {
        let mut term = tokio::signal::unix::signal(tokio::signal::unix::SignalKind::terminate())?;
        tokio::select! { result = tokio::signal::ctrl_c() => result?, _ = term.recv() => {} }
    }
    #[cfg(not(unix))] tokio::signal::ctrl_c().await?;
    Ok(())
}

fn main() -> Result<()> {
    hide_key()?;
    let args = Arc::new(Args::parse());
    for (name, value) in [("ws-timeout", args.ws_timeout), ("connect-timeout", args.connect_timeout), ("keepalive", args.keepalive), ("retry-delay", args.retry_delay)] {
        if !value.is_finite() || value <= 0.0 || value > 86400.0 { bail!("--{name} must be between 0 (exclusive) and 86400 seconds"); }
    }
    if args.api_key.is_empty() { bail!("Set NRD_API_KEY or pass --api-key"); }
    if args.keepalive <= args.ws_timeout { bail!("--keepalive must be greater than --ws-timeout"); }
    let runtime = tokio::runtime::Runtime::new()?;
    runtime.block_on(run(args))
}
async fn run(args: Arc<Args>) -> Result<()> {
    let file = File::create(&args.output_file).context("Cannot create output file")?;
    let stats = Arc::new(Mutex::new(Stats::new()));
    let (tx, rx) = mpsc::channel(CAPACITY);
    let (stop_tx, stop_rx) = watch::channel(false);
    let writer_stats = stats.clone(); let format = args.output_format;
    let mut writer_task = tokio::task::spawn_blocking(move || {
        let result = writer(file, format, rx, writer_stats.clone());
        if let Err(e) = &result { writer_stats.lock().unwrap().error(&format!("Output write failed: {e}"), false, true); }
        result
    });
    let mut stream_task = tokio::spawn(stream(args.clone(), stats.clone(), tx.clone(), stop_rx));
    let screen = Screen::enter()?;
    let mut tick = tokio::time::interval(Duration::from_millis(250));
    let signal = shutdown_signal(); tokio::pin!(signal);
    let outcome: Result<()> = loop {
        tokio::select! {
            result = &mut signal => { break result; }
            result = &mut stream_task => { break result.context("Stream task panicked").and_then(|r| r); }
            result = &mut writer_task => {
                let result = result.context("Writer task panicked").and_then(|r| r);
                let _ = stop_tx.send(true);
                let _ = stream_task.await;
                drop(screen);
                return result.and_then(|_| Err(anyhow::anyhow!("Writer stopped unexpectedly")));
            }
            _ = tick.tick(), if screen.0 => {
                if let Err(e) = render(&stats, &tx, &args) { break Err(e); }
            }
        }
    };
    stats.lock().unwrap().event("INFO", "Shutdown requested; finishing queued output.");
    let _ = stop_tx.send(true);
    // A completed JoinHandle must not be polled again.
    if !stream_task.is_finished() { let _ = stream_task.await; }
    drop(tx);
    let written = writer_task.await.context("Writer task panicked")?;
    drop(screen);
    let s = stats.lock().unwrap();
    eprintln!("Stopped. Records: {}. Written: {}. Dropped rows: {}.", s.records, s.written, s.dropped);
    written?; outcome
}
