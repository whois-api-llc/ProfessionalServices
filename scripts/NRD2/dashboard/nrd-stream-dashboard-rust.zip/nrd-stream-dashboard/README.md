# NRD Stream Dashboard — Rust

Rust conversion of the supplied Python NRD Ultimate stream client.

## Build and run

Install a current stable Rust toolchain, then:

```bash
cargo build --release
export NRD_API_KEY='YOUR_API_KEY'
./target/release/nrd-stream-dashboard output.csv
```

For newline-delimited JSON:

```bash
./target/release/nrd-stream-dashboard output.ndjson --output-format JSON
```

CSV is the default, regardless of the output filename extension. Output files
are overwritten at startup, matching the Python script. Only `added` records
are written; every reason contributes to dashboard totals.

## Options

| Option | Default |
| --- | --- |
| `--output-format`, `--outputFormat` | `CSV` (`JSON` selects NDJSON) |
| `--api-key` | `NRD_API_KEY` environment variable |
| `--ws-timeout` | 2 seconds |
| `--connect-timeout` | 15 seconds |
| `--keepalive` | 30 idle seconds |
| `--max-retries` | 5 |
| `--retry-delay` | 5 seconds |
| `--ws-url` (hidden from help) | `wss://nrd-stream.whoisxmlapi.com/ultimate` |

Time values must be finite, positive, and no more than 86400 seconds.
Keepalive must exceed the receive polling timeout.

## Preserved behavior

- API key sent as the first WebSocket text message over TLS.
- Text and binary frames, including multiple newline-separated JSON records.
- Counters for transactions, records, reasons, errors, reconnects, pings,
  written rows, and queue usage; latest six records and eight events.
- Idle pings and automatic responses to server pings.
- Queue capacity of 10000; enqueue waits up to 250 ms before dropping a row.
- Dedicated disk writer, CSV quoting, NDJSON encoding, local timestamps.
- Ctrl+C and Unix SIGTERM stop receiving and drain queued output.
- Retry count resets after a successful connection, as in the Python source.
- Unix re-execution removes a supplied API key from the running argv. Prefer
  the environment variable to avoid the initial command appearing in shell history.

## Implementation differences

Uses Tokio/tokio-tungstenite and a compact crossterm dashboard rather than
Python threads and Rich. Dashboard contents adapt to terminal size; terminal
control characters in server data are removed before display. Nonterminal
output prints a final summary rather than repeated dashboard frames.

The writer flushes each available batch (up to 500 rows), giving low-volume
streams immediate persistence. A writer failure stops the stream and returns
an error; retry exhaustion also returns a nonzero exit status. The dashboard
says the key was sent, since the protocol excerpt does not establish an
explicit authentication acknowledgement. No pong deadline is imposed, matching
the original client's behavior. API keys remain accessible to sufficiently
privileged processes through process memory/environment.

## Validation status

Source reviewed, but not compiled or integration-tested: this conversion
environment has no Rust compiler or Cargo. No live API connection was made.
Run `cargo check` and `cargo build --release` before production use. Dependencies
require network access on the initial build; Cargo.lock is generated then.
